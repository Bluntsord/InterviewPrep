class Solution():
    def __init__(self):
        self.solution = 0

    def print_0(self):
        print(self.solution)